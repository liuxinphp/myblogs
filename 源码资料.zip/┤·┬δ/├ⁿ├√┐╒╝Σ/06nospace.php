<?php


//没有空间（全局空间）
function display(){
	echo 'nospace';
}