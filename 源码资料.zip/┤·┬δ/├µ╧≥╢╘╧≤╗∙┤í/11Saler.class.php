<?php

//创建类
class Saler{
	public function __construct(){
		echo __METHOD__;
	}
}