<?php

	//规定：类名与文件名同名

class  Saler{
	public function __construct(){
		echo __METHOD__,'<br/>';
	}
}