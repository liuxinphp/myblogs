<?php

class Saler{
	//类常量
	const PI = 3.14;
}

//类访问类常量
echo Saler::PI;
