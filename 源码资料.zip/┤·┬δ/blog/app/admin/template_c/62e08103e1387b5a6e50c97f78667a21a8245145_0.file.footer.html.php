<?php
/* Smarty version 3.1.32, created on 2018-10-31 21:52:42
  from 'D:\blog\app\admin\view\Public\footer.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5bd9b3aa7a4aa8_13264916',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '62e08103e1387b5a6e50c97f78667a21a8245145' => 
    array (
      0 => 'D:\\blog\\app\\admin\\view\\Public\\footer.html',
      1 => 1540918816,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bd9b3aa7a4aa8_13264916 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="footer">
    	<div class="left-column">© Copyright 2020 - 保留所有权利.</div>
    </div>
<?php }
}
