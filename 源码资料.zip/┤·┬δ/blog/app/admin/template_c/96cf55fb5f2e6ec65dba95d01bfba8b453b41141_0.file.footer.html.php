<?php
/* Smarty version 3.1.32, created on 2018-11-01 22:41:55
  from 'D:\blog\app\admin\view\Public\footer.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5bdb10b3e34801_93217338',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '96cf55fb5f2e6ec65dba95d01bfba8b453b41141' => 
    array (
      0 => 'D:\\blog\\app\\admin\\view\\Public\\footer.html',
      1 => 1540918816,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bdb10b3e34801_93217338 (Smarty_Internal_Template $_smarty_tpl) {
?><div id="footer">
    	<div class="left-column">© Copyright 2020 - 保留所有权利.</div>
    </div>
<?php }
}
