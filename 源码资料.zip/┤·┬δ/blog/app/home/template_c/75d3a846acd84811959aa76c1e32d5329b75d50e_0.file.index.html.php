<?php
/* Smarty version 3.1.32, created on 2018-09-29 22:44:37
  from 'D:\server\mvc\app\home\view\Index\index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5baf8fd5dcd201_62224414',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '75d3a846acd84811959aa76c1e32d5329b75d50e' => 
    array (
      0 => 'D:\\server\\mvc\\app\\home\\view\\Index\\index.html',
      1 => 1538232275,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5baf8fd5dcd201_62224414 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	id: <?php echo $_smarty_tpl->tpl_vars['res']->value['s_id'];?>
<br/>
	name:<?php echo $_smarty_tpl->tpl_vars['res']->value['s_name'];?>

</body>
</html><?php }
}
