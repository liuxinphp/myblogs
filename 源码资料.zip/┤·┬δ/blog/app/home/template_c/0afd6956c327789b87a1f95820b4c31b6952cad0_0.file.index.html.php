<?php
/* Smarty version 3.1.32, created on 2018-10-30 22:01:33
  from 'D:\blog\app\home\view\Index\index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5bd8643d6b5e27_60276710',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0afd6956c327789b87a1f95820b4c31b6952cad0' => 
    array (
      0 => 'D:\\blog\\app\\home\\view\\Index\\index.html',
      1 => 1538232275,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5bd8643d6b5e27_60276710 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	id: <?php echo $_smarty_tpl->tpl_vars['res']->value['s_id'];?>
<br/>
	name:<?php echo $_smarty_tpl->tpl_vars['res']->value['s_name'];?>

</body>
</html><?php }
}
