<?php
/* Smarty version 3.1.32, created on 2018-09-20 01:06:22
  from 'D:\server\Web\10template.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ba2820e8e6543_11620319',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '12f00238d3ab74cdf21041ef380bc26c400aebcb' => 
    array (
      0 => 'D:\\server\\Web\\10template.html',
      1 => 1537376779,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ba2820e8e6543_11620319 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	abcdefg的长度是<?php echo strlen('abcdefg');?>
个字节


	自定义函数使用：<?php echo show();?>

</body>
</html><?php }
}
