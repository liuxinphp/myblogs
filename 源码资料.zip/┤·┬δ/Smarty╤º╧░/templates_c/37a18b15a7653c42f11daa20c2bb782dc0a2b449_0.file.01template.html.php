<?php
/* Smarty version 3.1.32, created on 2018-09-20 00:08:07
  from 'D:\server\Web\templates\01template.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ba27467b40ad5_55094730',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '37a18b15a7653c42f11daa20c2bb782dc0a2b449' => 
    array (
      0 => 'D:\\server\\Web\\templates\\01template.html',
      1 => 1537373285,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ba27467b40ad5_55094730 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo $_smarty_tpl->tpl_vars['hello']->value;?>
templates目录
</body>
</html><?php }
}
