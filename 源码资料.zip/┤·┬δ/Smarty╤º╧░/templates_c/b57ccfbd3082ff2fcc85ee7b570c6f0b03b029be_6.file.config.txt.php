<?php /* Smarty version 3.1.32, created on 2018-09-20 00:31:14
         compiled from 'D:\server\Web\smarty_config\config.txt' */ ?>
<?php
/* Smarty version 3.1.32, created on 2018-09-20 00:31:14
  from 'D:\server\Web\smarty_config\config.txt' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ba279d2a06ea4_58113902',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b57ccfbd3082ff2fcc85ee7b570c6f0b03b029be' => 
    array (
      0 => 'D:\\server\\Web\\smarty_config\\config.txt',
      1 => 1537374648,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ba279d2a06ea4_58113902 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'customer' => 
    array (
      'vars' => 
      array (
        'pageTitle' => 'Customer',
      ),
    ),
  ),
  'vars' => 
  array (
    'bgcolor' => '#00FF00',
    'pTitle' => 'hello',
  ),
));
}
}
