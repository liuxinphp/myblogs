<?php
/* Smarty version 3.1.32, created on 2018-09-19 23:57:36
  from 'D:\server\Web\01template.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5ba271f05c0498_49830317',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ea0ce293aa5d0a528f43f3d61a3b766624a0d47a' => 
    array (
      0 => 'D:\\server\\Web\\01template.html',
      1 => 1537370824,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ba271f05c0498_49830317 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo $_smarty_tpl->tpl_vars['hello']->value;?>

</body>
</html><?php }
}
